import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prerequisites',
  templateUrl: './prerequisites.component.html',
  styleUrls: ['./prerequisites.component.css'],
  inputs: ['oppurtunityResponseData']
})
export class PrerequisitesComponent implements OnInit {


  backgroundName:string="";
  skillSRequired:string="";
  skillSPreffered:string=""; 
  requiredLanguage:string="";
  studyLevels;
  
  oppurtunityResponseData = this.oppurtunityResponseData;

  constructor() { }

  ngOnInit() {
    this.oppurtunityResponseData.backgrounds.forEach(item => {
      if(this.backgroundName==""){
        this.backgroundName = item.name;
      }
      else{
        this.backgroundName = this.backgroundName + ',' + ' ' + item.name;
      }
  });

  this.oppurtunityResponseData.skills.forEach(item => {
    if(item.option == "required"){
    if(this.skillSRequired==""){
      this.skillSRequired = item.name;
    }
    else{
      this.skillSRequired = this.skillSRequired + ',' + ' ' + item.name;
    }
  }
});

this.oppurtunityResponseData.backgrounds.forEach(item => {
  if(item.option == "required"){
  if(this.skillSPreffered==""){
    this.skillSPreffered = item.name;
  }
  else{
    this.skillSPreffered = this.skillSPreffered + ',' + ' ' + item.name;
  }
}
});

this.oppurtunityResponseData.languages.forEach(item => {
  if(item.option == "required"){
  if(this.requiredLanguage==""){
    this.requiredLanguage = item.name;
  }
  else{
    this.requiredLanguage = this.requiredLanguage + ',' + ' ' + item.name;
  }
}
});

this.oppurtunityResponseData.study_levels.forEach(item => {
  if(this.studyLevels==""){
    this.studyLevels = item.name;
  }
  else{
    this.studyLevels = this.studyLevels + ',' + ' ' + item.name;
  }
});

}
}