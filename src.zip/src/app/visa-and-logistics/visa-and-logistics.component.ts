import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visa-and-logistics',
  templateUrl: './visa-and-logistics.component.html',
  styleUrls: ['./visa-and-logistics.component.css'],
  inputs: ['oppurtunityResponseData']
})
export class VisaAndLogisticsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
