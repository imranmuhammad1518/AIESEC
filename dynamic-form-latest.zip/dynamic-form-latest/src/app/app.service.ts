import {EventEmitter, Injectable} from '@angular/core';
import {FieldConfig} from './field.interface';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class AppService {
  receivedCountry: EventEmitter<string>;
  formElementConfig: FieldConfig[];

  constructor(private http: HttpClient) {
    this.receivedCountry = new EventEmitter<string>();
  }

  raiseEvent(country: string): void {

  }
}
