import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InputComponent } from './htmlcomponents/input/input.component';
import { ButtonComponent } from './htmlcomponents/button/button.component';
import { SelectComponent } from './htmlcomponents/select/select.component';
import { RadioComponent } from './htmlcomponents/radiobutton/radio.component';
import { CheckboxComponent } from './htmlcomponents/checkbox/checkbox.component';
import { DynamicFieldDirective } from './components/dynamic-field/dynamic-field.directive';
import { DynamicFormComponent } from './components/dynamic-form/dynamic-form.component';
import { AppRoutingModule } from './app-routing.module';
import {AppService} from './app.service';

@NgModule({
  declarations: [
    AppComponent,
    InputComponent,
    ButtonComponent,
    SelectComponent,
    RadioComponent,
    CheckboxComponent,
    DynamicFieldDirective,
    DynamicFormComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [AppService],
  bootstrap: [AppComponent],
  entryComponents: [
    InputComponent,
    ButtonComponent,
    SelectComponent,
    RadioComponent,
    CheckboxComponent
  ]
})

export class AppModule {}
