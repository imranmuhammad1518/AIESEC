import {Component, EventEmitter, OnChanges, OnInit, Output} from '@angular/core';
import {FormBuilder, FormControl, FormControlName, FormGroup} from '@angular/forms';
import { FieldConfig } from '../../field.interface';
import {AppService} from '../../app.service';

@Component({
  selector: 'app-select',
  template: `
    <div [formGroup]="group">
      <label>{{field.label}}</label>&nbsp;&nbsp;
      <select [formControlName]="field.name" [(ngModel)]="selectedCountry" (change)="selected()">
        <option *ngFor="let item of field.options" [ngValue]="item" [value]="item">{{item}}</option>
      </select>
    </div><br>
  `,
  styles: []
})
export class SelectComponent implements OnInit{
  field: FieldConfig;
  group: FormGroup;
  state: FormControl;
  options:any[];
  selectedCountry;
  loadFlag:boolean=false;

  @Output() emitOutput: EventEmitter<any> = new EventEmitter<any>();

  constructor(private fb: FormBuilder) { }

  ngOnInit() {

    // if (this.field.name == "state") {
    //   this.field.options = ["1", "3", "2"];
    // }
  }

      // this.emitOutput.emit(this.selectedCountry);
      //this.appService.raiseEvent(this.selectedCountry);

  selected() {
    // this.emitOutput.emit(this.selectedCountry);
    //this.appService.raiseEvent(this.selectedCountry);
  /*  console.log("Country selected as:: " + this.selectedCountry);
    this.getUrl = 'http://localhost:3000/' + this.selectedCountry;
    this.http.get(this.getUrl).subscribe(response => {
      this.response = response;
      console.log(this.response);
      this.field = this.response;
    })*/
  }

}
