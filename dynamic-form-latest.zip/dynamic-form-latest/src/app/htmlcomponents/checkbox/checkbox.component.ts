import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../../field.interface';
@Component({
  selector: 'app-radio',
  template: `<div [formGroup]="group">
    <label>{{field.label}}:</label>
    <div *ngFor="let item of field.options">
        <input [formControlName]="field.name" [value]='item' [type]="field.type">
        {{item}}
    </div>
  </div><br>`,
  styles: []
})
export class CheckboxComponent implements OnInit {
  field: FieldConfig;
  group: FormGroup;

  constructor() { }

  ngOnInit() {
  }

}
