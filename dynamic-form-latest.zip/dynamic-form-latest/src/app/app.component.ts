import {Component, Input, ViewChild} from '@angular/core';
import {FieldConfig} from './field.interface';
import { HttpClient } from '@angular/common/http';
import {DynamicFormComponent} from './components/dynamic-form/dynamic-form.component';
import {AppService} from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private http: HttpClient, private appService : AppService) {
    console.log(this.appService.formElementConfig);
  }
  getUrl:string;
  response;
  formElementConfig: FieldConfig[];
  loadFlag:boolean=false;



  ngOnInit() {
      this.getUrl = 'http://localhost:4000/template-1';
    //this.getUrl = 'http://localhost:4000/template-2';
      this.http.get(this.getUrl).subscribe(response => {
      this.response = response;
      this.formElementConfig = this.response;
      console.log("Response :", response);
      this.loadFlag=true;
    })
  }

    title = 'dynamic-htmlform';

  //formElementConfig: FieldConfig[] = this.response;

  @ViewChild(DynamicFormComponent, {static: false})
  form: DynamicFormComponent;

  submit(formValue){
    console.log(formValue);
  }
}
