import { Component, OnInit, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from "@angular/forms";
import {HttpClient} from '@angular/common/http';
import { FieldConfig } from '../../field.interface';
import {AppService} from '../../app.service';

@Component({
  selector: 'dynamic-form',
  template: `
    <form class="dynamic-form" [formGroup]="form" (submit)="submitForm()" (change)="selectedValue()">
        
      <ng-container *ngFor="let field of fields;" dynamicField [field]="field" [group]="form" >
      </ng-container>
        
        <button type="submit" [disabled]="form.invalid">Submit</button>
        <div *ngIf="submitted"><pre>{{form.value | json}}</pre></div>
    </form>
  `,
  styles: []
})
export class DynamicFormComponent implements OnInit, OnChanges {
  @Input() loadFlag : boolean;
  selectedCountry: string;
  @Input() fields: FieldConfig[];
  @Output() submit: EventEmitter<any> = new EventEmitter<any>();
  api:any;
  getUrl:string;
  response;
  form: any;
  submitted: boolean;
  states = [];

  constructor(private fb: FormBuilder, private http: HttpClient) {
  }

  ngOnInit() {
  }

  selectedValue(){
   // console.log("formmm:::"+ JSON.stringify(this.fields.api));
    if (this.form.value.country!= null || "") {
      console.log("Country selected as:: " + this.form.value.country);
      this.selectedCountry = this.form.value.country
      this.getUrl = "http://localhost:3000/" + this.selectedCountry;
      this.http.get(this.getUrl).subscribe(response => {
        this.response = response;//
       // this.states.push("chennai");
        //this.states.push("bangalore");
        //this.states.push("delhi");
        console.log("this.form.value::", this.form.value);
     /*   const control = this.fb.control(
          this.form.value
        );*/

        this.form = this.fb.control({
          state: [[1, 2, 3, 4]]
        });
        console.log("group::" + this.form.value);
        //this.form.controls['state'].setValue(this.response);
        //console.log("final:" + this.fields[6].value);
      });
      this.form = this.fb.control({
        state: [[1, 2, 3, 4]]
      });
    }
  }

  emitOutput(statesResponse){
   this.fields = statesResponse;
  }

  submitForm() {
    this.submitted = true;
  }

  ngOnChanges(): void {
    if(this.loadFlag) {
      this.form = this.createControl();
    }
  }

  get value() {
    return this.form.value;
  }
  createControl() {
    const group = this.fb.group({});
    this.fields.forEach(field => {
      if (field.type === 'button') return;
      const control = this.fb.control(
        field.value,
        this.bindValidations(field.validations || [])
      );
      group.addControl(field.name, control);
    });
    return group;
  }
  bindValidations(validations: any) {
    if (validations.length > 0) {
      const validList = [];
      validations.forEach(valid => {
        validList.push(valid.validator);
      });
      return Validators.compose(validList);
    }
    return null;
  }
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      control.markAsTouched({ onlySelf: true });
    });
  }
  onSubmit(event: Event) {
    event.preventDefault();
    event.stopPropagation();
    console.log(this.form.valid);
    if (this.form.valid) {
      //this.submit.emit(this.form.value);
    } else {
      this.validateAllFormFields(this.form);
    }
  }
}
