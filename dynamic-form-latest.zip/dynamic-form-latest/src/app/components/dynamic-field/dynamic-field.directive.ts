import {Directive, ComponentFactoryResolver, ComponentRef, Input, OnInit, OnChanges, ViewContainerRef, SimpleChanges} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../../field.interface';
import { InputComponent } from '../../htmlcomponents/input/input.component';
import { ButtonComponent } from '../../htmlcomponents/button/button.component';
import { SelectComponent } from '../../htmlcomponents/select/select.component';
import { RadioComponent } from '../../htmlcomponents/radiobutton/radio.component';
import { CheckboxComponent } from '../../htmlcomponents/checkbox/checkbox.component';

const componentMapper = {
  input: InputComponent,
  button: ButtonComponent,
  select: SelectComponent,
  radio: RadioComponent,
  checkbox: CheckboxComponent
};
@Directive({
  selector: '[dynamicField]'
})
export class DynamicFieldDirective {

  @Input() field: FieldConfig;
  @Input() group: FormGroup;
  componentRef: any;
  constructor(private resolver: ComponentFactoryResolver,
              private container: ViewContainerRef) {
  }
  ngOnInit() {
    const factory = this.resolver.resolveComponentFactory(
      componentMapper[this.field.type]
    );
    this.componentRef = this.container.createComponent(factory);
    this.componentRef.instance.field = this.field;
    this.componentRef.instance.group = this.group;
  }

}
